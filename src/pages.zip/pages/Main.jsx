
import { TabPanelUnstyled } from '@mui/base';
import { Tab, Tabs } from '@mui/material';
import { Box } from '@mui/system';
import React, { useState } from 'react';
import { Link, Outlet, useNavigate } from 'react-router-dom';


const Main = () => {
    const [value, setValue] = useState(0);
    const navigate = useNavigate()

    const handleChange = (event, newValue) => {
       setValue(newValue);
       console.log(event.target.id);
       navigate(`/${event.target.id}`)
    };
    
    return (
        <React.Fragment>
            <Tabs value={value} onChange={handleChange} centered>
                <Tab label="info" id='info' />
                <Tab label="alboms"  id='alboms' />
                <Tab label="posts"  id='posts'/>
                <Tab label="todos"  id='todos'/>
            </Tabs>
            <Outlet />
        </React.Fragment>
    );
}

export default Main;
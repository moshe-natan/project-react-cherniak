import React, { useState } from 'react';

const Alboms = () => {
    return ( 
        <React.Fragment>
            
        </React.Fragment>
     );
}
 
export default Alboms;
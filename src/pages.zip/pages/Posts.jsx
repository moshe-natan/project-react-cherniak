import React, { useState } from 'react';

const Posts = () => {
    return ( 
        <React.Fragment>
            
        </React.Fragment>
     );
}
 
export default Posts;
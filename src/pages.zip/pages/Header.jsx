import React, { useEffect, useState } from 'react';
import './header.css'

const Header = () => {
    const [user, setUser] = useState() 

    useEffect(() => {
       setUser(JSON.parse(sessionStorage.getItem('user')))  
    }, [])
    

    return ( 
        <React.Fragment>
            <div className='headerBox'>
                {user && <h2>wellcome {user['name']}</h2>}
            </div>
        </React.Fragment>
     );
}
 
export default Header;